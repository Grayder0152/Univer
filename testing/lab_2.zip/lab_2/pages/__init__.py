from .login import LoginPage
from .register import RegisterPage
from .product import ProductPage
